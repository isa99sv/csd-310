""" Title: bacchus_winery.py
    Author: Colton Stone, Aysa Jordan, and Eric Brown
    Date: December 13, 2025,
    Description: This code is written to display a database which depicts the logistics of a wine company."""

import mysql.connector # to connect
from mysql.connector import errorcode

import dotenv # to use .env file
dotenv.load_dotenv()
from dotenv import dotenv_values

#using our .env file
secrets = dotenv_values(".env")

""" database config object """
config = {
    "user": secrets["USER"],
    "password": secrets["PASSWORD"],
    "host": secrets["HOST"],
    "database": secrets["DATABASE"],
    "raise_on_warnings": True #not in .env file
}

try:
    """ try/catch block for handling potential MySQL database errors """

    db = mysql.connector.connect(**config)  # connect to the Bacchus database

    # output the connection status
    print("\n  Database user {} connected to MySQL on host {} with database {}".format(config["user"], config["host"],
                                                                                       config["database"]))

    input("\nPress any key to continue...")

    cursor = db.cursor()

    # ----------------------SUPPLIER REPORT----------------------


    month1 = ("""SELECT supplier_name, emonth_1, amonth_1,
                 IF (emonth_1 = amonth_1, 'Passed', 'Missed') FROM supplier""")

    cursor.execute(month1)
    month1_records = cursor.fetchall()


    month2 = ("""SELECT supplier_name, emonth_2, amonth_2,
                     IF (emonth_2 = amonth_2, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month2)
    month2_records = cursor.fetchall()


    month3 = ("""SELECT supplier_name, emonth_3, amonth_3,
                         IF (emonth_3 = amonth_3, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month3)
    month3_records = cursor.fetchall()


    month4 = ("""SELECT supplier_name, emonth_4, amonth_4,
                             IF (emonth_4 = amonth_4, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month4)
    month4_records = cursor.fetchall()

    month5 = ("""SELECT supplier_name, emonth_5, amonth_5,
                     IF (emonth_5 = amonth_5, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month5)
    month5_records = cursor.fetchall()

    month6 = ("""SELECT supplier_name, emonth_6, amonth_6,
                         IF (emonth_6 = amonth_6, 'Passed', 'Missed') FROM supplier""")

    cursor.execute(month6)
    month6_records = cursor.fetchall()

    month7 = ("""SELECT supplier_name, emonth_7, amonth_7,
                             IF (emonth_7 = amonth_7, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month7)
    month7_records = cursor.fetchall()

    month8 = ("""SELECT supplier_name, emonth_8, amonth_8,
                                 IF (emonth_8 = amonth_8, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month8)
    month8_records = cursor.fetchall()

    month9 = ("""SELECT supplier_name, emonth_9, amonth_9,
                                     IF (emonth_9 = amonth_9, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month9)
    month9_records = cursor.fetchall()

    month10 = ("""SELECT supplier_name, emonth_10, amonth_10,
                                     IF (emonth_10 = amonth_10, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month10)
    month10_records = cursor.fetchall()


    month11 = ("""SELECT supplier_name, emonth_11, amonth_11,
                                        IF (emonth_11 = amonth_11, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month11)
    month11_records = cursor.fetchall()

    month12 = ("""SELECT supplier_name, emonth_12, amonth_12,
                                        IF (emonth_12 = amonth_12, 'Passed', 'Missed')  FROM supplier""")

    cursor.execute(month12)
    month12_records = cursor.fetchall()


    print("\n------Supplier Annual Delivery Report----: ")

    print("\n{JANUARY}")
    for sup in month1_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{February}")
    for sup in month2_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{March}")
    for sup in month3_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{April}")
    for sup in month4_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{May}")
    for sup in month5_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{June}")
    for sup in month6_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{July}")
    for sup in month7_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{August}")
    for sup in month8_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{September}")
    for sup in month9_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{October}")
    for sup in month10_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{November}")
    for sup in month11_records:
        print("\n{}: {}.".format(sup[0], sup[3]))

    print("\n{December}")
    for sup in month12_records:
        print("\n{}: {}.".format(sup[0], sup[3]))
    print()

    print("\nGreen Glass & Packaging were on schedule 12 out of 12 months this year.")
    print("\nDaily Express were on schedule 10 out of 12 months this year.")
    print("\nG3 Industries were on schedule 9 out of 12 months this year.")
    print()


    # ----------------------WINE DISTRIBUTION REPORT----------------------

    dis_list = ("""SELECT wine_name as Name, wine_type as Type, distributor_name as 'Distributor Name'
                FROM wine
                INNER JOIN distributor ON distributor.wine_id = wine.wine_id
                WHERE wine_name IN ('Cabernet', 'Chablis', 'Chardonnay', 'Merlot')""")

    cursor.execute(dis_list)
    dis_records = cursor.fetchall()

    wine_hsales = ("""SELECT wine_name as highpf, expected_gallonsales - actual_gallonsales as difference FROM wine
                       WHERE expected_gallonsales <= actual_gallonsales""")

    cursor.execute(wine_hsales)
    hsales_records = cursor.fetchall()



    wine_lsales = ("""SELECT wine_name as lowpf, expected_gallonsales - actual_gallonsales as difference FROM wine
                WHERE expected_gallonsales > actual_gallonsales""")

    cursor.execute(wine_lsales)
    lsales_records = cursor.fetchall()


    max_list = ("""SELECT w1.wine_name, MAX(w1.actual_gallonsales) FROM wine w1 
                  INNER JOIN wine w2 ON w2.wine_id = w1.wine_id
                  WHERE w1.wine_name IN ('Cabernet', 'Chablis', 'Chardonnay', 'Merlot')
                  GROUP BY w1.wine_name, w2.wine_name
                  ORDER BY MAX(w1.actual_gallonsales) DESC
                  LIMIT 1""")

    cursor.execute(max_list)
    max_records = cursor.fetchall()


    min_list = ("""SELECT w1.wine_name, MAX(w1.actual_gallonsales) FROM wine w1 
                      INNER JOIN wine w2 ON w2.wine_id = w1.wine_id
                      WHERE w1.wine_name IN ('Cabernet', 'Chablis', 'Chardonnay', 'Merlot')
                      GROUP BY w1.wine_name, w2.wine_name
                      ORDER BY MAX(w1.actual_gallonsales) ASC
                      LIMIT 1""")

    cursor.execute(min_list)
    min_records = cursor.fetchall()

    print()
    print("\n------WINE Distribution Report-----: ")

    for dis in dis_records:
        print("\nThe {} brand is a {} variety that is carried by the {} company.".format(dis[0], dis[1], dis[2]))
        print()
    print("\n------Results from Our Sales Reports-----:")

    for high in hsales_records:
        print("\nThe {} brand reached our expected numbers.".format(high[0]))


    for low in lsales_records:
        print("\nThe {} brand underperformed in sales this year by approximately {} gallons.".format(low[0], low[1]))


    for max in max_records:
        print("\nThe {} brand sold the highest.".format(max[0]),end="")

    for min in min_records:
        print(" and the {} brand sold the lowest.".format(min[0]))
        print()

    # ----------------------EMPLOYEE REPORT----------------------

    employee_list = ("""SELECT employee_name as Name, employee_title as Role, annual_workhours as "Annual Hours" FROM employee""")

    cursor.execute(employee_list)
    employee_records = cursor.fetchall()

    print()
    print("\n------Employee Annual Work Report----: ")

    for emps in employee_records:
        print("\n{}, the company's {} worked a total of {} hours this year.".format(emps[0], emps[1], emps[2]))
        print()



except mysql.connector.Error as err:
    """ on error code """

    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("  The supplied username or password are invalid")

    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("  The specified database does not exist")

    else:
        print(err)

finally:
    """ close the connection to MySQL """

db.close()
